# StudentCoursesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**student_id** | **int** |  | 
**student_name** | **str** |  | 
**academic_year** | **str** |  | 
**semester** | **str** |  | 
**courses** | [**list[StudentCoursesResponseCourses]**](StudentCoursesResponseCourses.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

