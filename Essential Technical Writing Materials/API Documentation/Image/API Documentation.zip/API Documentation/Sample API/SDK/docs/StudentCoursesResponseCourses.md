# StudentCoursesResponseCourses

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**course_code** | **str** |  | [optional] 
**course_name** | **str** |  | [optional] 
**credits** | **int** |  | [optional] 
**instructor** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

