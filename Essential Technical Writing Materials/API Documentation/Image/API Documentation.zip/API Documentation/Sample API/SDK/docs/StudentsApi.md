# swagger_client.StudentsApi

All URIs are relative to *https://virtserver.swaggerhub.com/self-634-067/1510_Nav_Sample/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**students_student_id_courses_get**](StudentsApi.md#students_student_id_courses_get) | **GET** /students/{studentId}/courses | get the courses associated with a student

# **students_student_id_courses_get**
> StudentCoursesResponse students_student_id_courses_get(student_id, academic_year=academic_year, semester=semester)

get the courses associated with a student

Retrieves the list of courses the student has enrolled into. Use the student_id to identify the student. You can optionally specify an academic year and a semester to retrieve courses for a given period.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.StudentsApi()
student_id = 56 # int | Unique identifier of the student.
academic_year = 'academic_year_example' # str |  (optional)
semester = 'semester_example' # str |  (optional)

try:
    # get the courses associated with a student
    api_response = api_instance.students_student_id_courses_get(student_id, academic_year=academic_year, semester=semester)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StudentsApi->students_student_id_courses_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **student_id** | **int**| Unique identifier of the student. | 
 **academic_year** | **str**|  | [optional] 
 **semester** | **str**|  | [optional] 

### Return type

[**StudentCoursesResponse**](StudentCoursesResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

